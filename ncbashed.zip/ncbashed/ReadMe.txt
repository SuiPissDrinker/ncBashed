Hello, I am SuiPissDrinker.
I wrote this little program because I wanted to be able to transfer files from my laptop to my main pc without using a usb medium. 
---------------------
You can edit the type of files the program sends and recieves by editing the bash file. It's up at the top. Just read the comments
It should create the files it's using if they don't already exist, but you makehave to manuallly make them depending on your sytem and choice of files.
---------------------
My GitHub https://github.com/SuiPissDrinker.
---------------------
Have a great day you stinky little meat nugget.
