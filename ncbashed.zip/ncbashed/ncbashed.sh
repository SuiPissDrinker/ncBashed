#!/bin/bash
ipToConnectTo="hahahretardIremovedmypersonalipeatmyass"
portNumber="69420"
sendFile="send.7z"
recFile="rec.7z"

if [ $3 != "" ]
then
ipToConnectTo=$3
fi
if [ $4 != "" ]
then
portNumber=$4
fi

echo "-----------------------------------------"
echo "My GitHub: https://github.com/SuiPissDrinker"
echo "Make sure you have netcat installed on your system, or you this script will piss and shit itself lol"
echo "-----------------------------------------"
#mfw if statement garbage. This is the code that handles what nc connection to make
if [ $1 == "-s" ] && [ $2 == "-h" ] 
then
echo "entering host sending mode"
nc -nvlp $portNumber < $sendFile
fi
if [ $1 == "-r" ] && [ $2 == "-h" ]
then
echo "entering host rec mode"
nc -nvlp $portNumber >> $recFile
fi
if [ $1 == "-s" ] && [ $2 == "-c" ]
then
echo "entering client sending mode"
nc -v $ipToConnectTo $portNumber < $sendFile
fi
if [ $1 == "-r" ] && [ $2 == "-c" ]
then 
echo "entering rec client mode"
nc -v $ipToConnectTo $portNumber > $recFile
fi

#help
if [ $1 == "-h" ] || [ $1 == "--help" ] 
then 
echo "-----------------------------------------"
echo "This is the hlp page for ncbashed"
echo "It's just a basic little script I wrote for sending and reciveing data over the network, but it servers me well, and now it will server you well too"
echo "This script's command line args are as follows:"
echo "-s : will make it so YOU are SENDING the data."
echo "-r : will make it so YOU are BEING SENT the data"
echo "-h : will make it so YOU are the HOST"
echo "-c : will make it so YOU are the CLIENT"
echo "Note: You must use it in the order of ( ./ncbashed -{Send/rec mode} -{host/client mode} ipaddr portnumber ) or it will not work because I am an L programmer"
echo "-----------------------------------------"
echo "-h || --help : will show this page again"
echo " "
echo "You can specify the ip addresses to be used by either changing the bash file, or by using the third and fourth position arguments."
echo "Ex : ./ncbashed -s -h ipaddr portnumber"
echo "Note: You must use it in the order of ( ./ncbashed -{Send/rec mode} -{host/client mode} ipaddr portnumber ) or it will not work because I am an L programmer"
echo "Note: During -h mode, you don't need to supply an Ip. Just imput whatever gibberish you want for this argument. (It does still need the argument to be filled)"
echo "-----------------------------------------"
echo my GitHub : https://github.com/SuiPissDrinker
echo "-----------------------------------------"
else
echo "Whoopise doopsie, you entered the command line args wrong, OR the connection closed. Type ./ncbashed -h or ./ncbashed --help for the manual"
fi